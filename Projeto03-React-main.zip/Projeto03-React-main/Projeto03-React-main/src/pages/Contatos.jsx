import '../App.css'
import Header from '../contents/header'
import Nav from '../contents/Nav'
import Footer from '../contents/Footer'

function Contatos(){
    return(
        <>
        <Header/>
        <Nav/>
        <Footer/>
        </>
    )
}
export default Contatos