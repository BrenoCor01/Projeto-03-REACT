import Article from "./Article"
import Aside from "./Aside"

function Main(){
    return(

        <main className="principal">
            <Article />
            <Aside />
        </main> 

    )
}

export default Main