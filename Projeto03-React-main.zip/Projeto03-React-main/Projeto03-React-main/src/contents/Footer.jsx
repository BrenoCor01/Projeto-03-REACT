function Footer(){
    return(
    <footer className="rodape">
        <p>Loja do obama - Todos os direitos reservados.&copy;</p>
    </footer>
    )
}

export default Footer