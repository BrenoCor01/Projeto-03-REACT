function Produto(){
    return(
    <article className="produtos">
        <img src="/public/pc.jpg" alt="Imagem de um computador" />
        <p>Computador da marca Android <br /> R$2.159,99</p>
        <button>Ver Produto</button>
    </article> 
    )
}

export default Produto